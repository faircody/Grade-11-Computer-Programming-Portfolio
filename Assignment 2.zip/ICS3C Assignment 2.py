# ---------------------------------------------------------
# Academic Integrity Declaration
# I, Cody Fairburn, confirm that this work is my
# own. I have not used AI tools or received external help.
# ---------------------------------------------------------
# =========================================================
# TASK 1: Vending Machine Program
# ---------------------------------------------------------
# Requirements:
# - Simulate a vending machine with 3 items:
#     1. Chips – $2.00
#     2. Chocolate – $2.50
#     3. Soda – $3.00
# - Ask user to choose an item (1–3)
# - Ask user to insert money
# - If money < cost → print "Not enough money. Transaction cancelled."
# - If money == cost → print "Enjoy your item!"
# - If money > cost → print "Enjoy your item! Your change is $X."

chips = 2
chocolate = 2.50
soda = 3

print("Chips = $2 Chocolate = $2.50 Soda = $3.00")
      
moneyinput = float(input("How much money will you insert?"))
item_wanted = input("Which item do you want?")

if item_wanted == "chips":
    if moneyinput == 2 and item_wanted == "chips":
        print("Enjoy your item!")
elif moneyinput > 2.00 and item_wanted == "chips":
                change = moneyinput - chips
                print(f"Enjoy your item! Your change is ${chips}")

elif item_wanted == "chips":
    print("Not enough money, transaction cancelled")
                
if item_wanted == "chocolate":
    if moneyinput == 2.50 and item_wanted == "chocolate":
        print("Enjoy your item!")
elif moneyinput > 2.50 and item_wanted == "chocolate":
                change = moneyinput - chocolate
                print(f"Enjoy your item! Your change is ${chips}")

elif item_wanted == "chocolate":
    print("Not enough money, transaction cancelled")

if item_wanted == "soda":
    if moneyinput == 3.00 and item_wanted == "soda":
        print("Enjoy your item!")
elif moneyinput > 3.00 and item_wanted == "soda":
                change = moneyinput - soda
                print(f"Enjoy your item! Your change is ${chips}")

elif item_wanted == "soda" and item_wanted == "soda":
    print("Not enough money, transaction cancelled")




# Pseudocode:
# (Write your pseudocode here as comments)
# Get input for money and item wanted
# Check if they want chips, chocolate, or soda
# Depending on item and money entered, return change or cancel transaction
# Flowchart:
# (Write your flowchart description here as comments, or attach separately)
#
# Python Code:
# =========================================================
# (Write your Python code here)




# =========================================================
# TASK 2: Movie Ticket Price Calculator
# ---------------------------------------------------------
# Requirements:
# - Ask user for age
# - Ask if user is a student (Yes/No)
# - Ticket prices:
#     Under 12 → $8
#     12–17 → $10
#     18–64 → $12
#     65+ → $6
# - If student AND over 12 → $2 discount
# - Output final ticket price
#


age = float(input("How old are you?"))
student = str(input("Are you a student?"))

if age <= 12:
    price = 8

if age >= 12 and age < 18:
    price = 10

if age >= 18 and age < 65:
    price = 12
    
if age > 64:
    price = 6

if age > 12 and student == "yes":
    price = price - 2

print(f"Your ticket is ${price}")





# Pseudocode:
# (Write your pseudocode here as comments)
#
# Flowchart:
# (Write your flowchart description here as comments, or attach separately)
#
# Python Code:
# =========================================================
# (Write your Python code here)
