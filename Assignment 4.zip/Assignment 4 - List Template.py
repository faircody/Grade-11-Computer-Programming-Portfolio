"""
Assignment 4 - List
Name: Cody Fairburn
Date: December 11
________________________________________________________________________________________________
PART A
________________________________________________________________________________________________
Prompt the user to enter positive numbers repeatedly which represent test scores. 
Continue accepting float inputs until the user enters -1.  
Value -1 will act as a sentinel to stop the input process. 
Store all positive numbers entered by the user in a list.  
After input ends, loop through the list and print each number on a new line. - This needs to be completed for a Level 4  
Bonus: Calculate the average of the test scores – One bonus mark
"""
scores = []
testinput = 0

while testinput != -1:
    testinput = float(input("Enter test scores (type -1 to stop): "))

    if testinput > 0:
        scores.append(testinput)
    else:
        print("Enter -1 to stop")

for score in scores:
    print(score)
        


"""
________________________________________________________________________________________________
PART B
________________________________________________________________________________________________
Prompt the user to enter words repeatedly. 
Continue accepting input until the user enters "quit".  
The word "quit" will act as a stop for the input process. 
Store all words entered by the user in a list. 
After input ends, display all the words in the list. 
Ask the user if they want to check whether a specific word exists in the list: - This needs to be completed for a level 4 Level 4 
If yes, prompt them to enter a word. 
Display whether the word is found in the list.  
You may assume that the names are all lowercase including the word quit – You will lose marks for using upper(), lower() or find() 
"""

words = []
userinput = 0

while userinput != "quit":
    userinput = input("Enter a word, type quit to end loop")

    words.append(userinput)

for w in words:
    print(w)

wordcheck = input("Do you want to check for a word in the list?")
if wordcheck == "yes":
    searchword = input("Enter the word you wish to search for?")
    if searchword in words:
        print(f"{searchword} was found in the list!")
    else:
        print(f"{searchword} was not found in the list")



