"""
===============================================
Assignment 1 – Python Programming
Student Name: Cody Fairburn
Date: September 20th, 2025

By typing my name above, I confirm that this is my own work
and I have not plagiarized or copied code from others or AI sources.
===============================================
"""

# =======================================================
# Question 1: Say Hello
# Write a program that asks the user for their name
# and prints: Hello, <name>!
# =======================================================

name = input("What is your name?")
print(f"Hello {name}")


# =======================================================
# Question 2: Adding Numbers
# Ask the user to enter two numbers. Add them together
# and print the result.
# =======================================================

num1 = int(input("What is your first number?"))
num2 = int(input("What is your second number?"))
print(num1 + num2)

# =======================================================
# Question 3: Average of Three Numbers
# Ask the user to enter three numbers. Calculate the
# average and print it.
# =======================================================

averagenum1 = int(input("What is the first number you want to average?"))
averagenum2 = int(input("What is the second number you want to average?"))
averagenum3 = int(input("What is the third number you want to average?"))
average = ((averagenum1 + averagenum2 + averagenum3)/3)
print(f"The average of the three numbers is {average}")


# =======================================================
# Question 4: Pizza Shop – Calculate Tax
# Ask the user to enter the total cost of their order.
# Calculate 13% tax and print the total amount including tax.
# ===============

total_no_tax = float(input("What is the total of your purchase?"))
tax = (total_no_tax*0.13)
total = (total_no_tax + tax)

print(f"Your total is {total} including tax.")

# =======================================================
# Question 5: Rectangle Area Calculator
# Calculate the area of a rectangle
# ===============

length = int(input("What is the length of the rectangle?"))
width = int(input("What is the width of the rectangle?"))
area = (length*width)
print(f"The area of the rectangle is {area}.")

# =======================================================
# Question 6: Tip Calculator
# Ask the user to enter the total bill amount at a restaurant.
# Ask the user to enter a tip percentage (e.g., 15 for 15%).
# Calculate the tip amount and the total bill including tip.
# Print both values clearly.
# =======================================================

rest_total = float(input("What is your total?"))
tip_percent = float(input("What percent of tip do you want to give? Submit in decimal."))
tip = (rest_total*tip_percent)
total_tip = (tip+rest_total)
print(f"Tip = {tip}")
print(f"Total including tip = {total_tip}")

        



