Python 3.13.3 (tags/v3.13.3:6280bb5, Apr  8 2025, 14:47:33) [MSC v.1943 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
>>> 
= RESTART: D:\Schoolwork\Grade 11 Programming\Assignment 1\ICS3C Assignment 1.py
What is your name?1
Hello 1
What is your first number?1
What is your second number?1
2
What is the first number you want to average?1
What is the second number you want to average?1
What is the third number you want to average?1
The average of the three numbers is 1.0
What is the total of your purchase?1
Your total is 1.13 including tax.
What is the length of the rectangle?1
What is the width of the rectangle?1
The area of the rectangle is 1.
What is your total?20
What percent of tip do you want to give? Submit in decimal.0.10
Tip = 2.0
Total including tip = 22.0
